export declare class UserInputData {
    productName: string;
    productDescription: string;
    price: number;
}
