export declare const JSONParse: <A>(str: string | null) => A;
