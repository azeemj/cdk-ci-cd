import { UserInputData } from './models/UserInputData';
import { UserData } from './models/UserData';
export declare class CloudUserManager {
    create(user: UserInputData): Promise<UserData>;
    getById(id: string): Promise<UserData>;
    getall(): Promise<UserData[]>;
}
declare const _default: CloudUserManager;
export default _default;
