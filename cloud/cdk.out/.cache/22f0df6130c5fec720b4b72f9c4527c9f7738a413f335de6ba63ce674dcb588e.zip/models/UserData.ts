

export class UserData{
    id:string;
    productName:string;
    productDescription:string;
    price: number;
}