import { UserInputData } from './models/UserInputData';
import { UserData } from './models/UserData';
export declare class CloudProductManager {
    create(user: UserInputData): Promise<UserData>;
    getById(id: string): Promise<UserData>;
    getall(): Promise<UserData[]>;
}
declare const _default: CloudProductManager;
export default _default;
