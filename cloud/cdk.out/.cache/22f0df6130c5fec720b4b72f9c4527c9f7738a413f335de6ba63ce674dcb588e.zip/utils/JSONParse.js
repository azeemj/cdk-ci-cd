"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JSONParse = void 0;
exports.JSONParse = (str) => {
    if (str && str !== '') {
        try {
            return JSON.parse(str);
        }
        catch (error) {
            throw new Error(`Could not parse ${str}`);
        }
    }
    else {
        throw new Error(`Could not parse empty string`);
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiSlNPTlBhcnNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiSlNPTlBhcnNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFhLFFBQUEsU0FBUyxHQUFHLENBQUksR0FBa0IsRUFBSyxFQUFFO0lBQ2xELElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSyxFQUFFLEVBQUU7UUFDbkIsSUFBSTtZQUNBLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQU0sQ0FBQztTQUMvQjtRQUFDLE9BQU8sS0FBSyxFQUFFO1lBQ1osTUFBTSxJQUFJLEtBQUssQ0FBQyxtQkFBbUIsR0FBRyxFQUFFLENBQUMsQ0FBQTtTQUM1QztLQUNKO1NBQU07UUFDSCxNQUFNLElBQUksS0FBSyxDQUFDLDhCQUE4QixDQUFDLENBQUE7S0FDbEQ7QUFDTCxDQUFDLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgSlNPTlBhcnNlID0gPEE+KHN0cjogc3RyaW5nIHwgbnVsbCk6IEEgPT4ge1xuICAgIGlmIChzdHIgJiYgc3RyICE9PSAnJykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2Uoc3RyKSBhcyBBO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBDb3VsZCBub3QgcGFyc2UgJHtzdHJ9YClcbiAgICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgQ291bGQgbm90IHBhcnNlIGVtcHR5IHN0cmluZ2ApXG4gICAgfVxufTsiXX0=