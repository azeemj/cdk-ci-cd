export declare const extractUserId: (event: import("aws-lambda").APIGatewayProxyEvent) => string;
declare const _default: {
    extractUserId: (event: import("aws-lambda").APIGatewayProxyEvent) => string;
};
export default _default;
