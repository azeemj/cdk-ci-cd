export default class NotDetectedError extends Error {
    constructor();
}
