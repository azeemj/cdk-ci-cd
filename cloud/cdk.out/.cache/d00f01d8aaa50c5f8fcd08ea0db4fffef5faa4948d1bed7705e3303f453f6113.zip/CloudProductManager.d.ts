import { ProductInputData } from './models/ProductInputData';
import { ProductData } from './models/ProductData';
export declare class CloudProductManager {
    create(user: ProductInputData): Promise<ProductData>;
    getById(id: string): Promise<ProductData>;
    getall(): Promise<ProductData[]>;
}
declare const _default: CloudProductManager;
export default _default;
