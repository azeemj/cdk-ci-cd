

export class ProductData{
    id:string;
    productName:string;
    productDescription:string;
    price: number;
}