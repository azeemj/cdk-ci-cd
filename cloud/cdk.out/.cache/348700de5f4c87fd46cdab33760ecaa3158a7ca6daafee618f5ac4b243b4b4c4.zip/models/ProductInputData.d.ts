export declare class ProductInputData {
    productName: string;
    productDescription: string;
    price: number;
}
