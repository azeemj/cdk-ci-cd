export class UserInputData{

    firstName: string;
    lastName: string;
    price: number;

}