export declare class UserData {
    id: string;
    firstName: string;
    lastName: string;
    price: number;
}
