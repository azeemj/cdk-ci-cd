

export class UserData{
    id:string;
    firstName:string;
    lastName:string;
    price: number;
}